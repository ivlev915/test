# html-scss-js-simple-boilerplate
Simple webpack 5 boilerplate for html-scss-js.

## Setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run start
```

### Compiles and minifies for production
```
npm run build
```
